import { Link, useNavigate } from 'react-router-dom'
import { useState, useEffect } from 'react'
import { useAuth } from '../context/AuthContext'
import { useCart } from '../context/CartContext'
import { supabase } from '../lib/supabase'

export default function Header() {
  const { user, profile, signOut } = useAuth()
  const { itemCount } = useCart()
  const navigate = useNavigate()
  const [query, setQuery] = useState('')
  const [categories, setCategories] = useState([])

  useEffect(() => {
    supabase.from('categories').select('*').order('sort_order').then(({ data }) => setCategories(data || []))
  }, [])

  function handleSearch(e) {
    e.preventDefault()
    if (query.trim()) navigate(`/search?q=${encodeURIComponent(query.trim())}`)
  }

  return (
    <>
      <div className="topbar">🚚 Free delivery on orders above ₹299 &nbsp;·&nbsp; Fresh groceries, delivered to your door</div>
      <header className="header">
        <div className="header-inner container">
          <Link to="/" className="logo">JJ<span>Mart</span> <small>SUPERSTORE</small></Link>
          <form className="search-bar" onSubmit={handleSearch}>
            <input
              type="text"
              placeholder="Search for atta, rice, oil, soap..."
              value={query}
              onChange={e => setQuery(e.target.value)}
              aria-label="Search products"
            />
            <button type="submit" aria-label="Search">🔍</button>
          </form>
          <div className="header-actions">
            {user ? (
              <>
                <Link to="/orders">📦 Orders</Link>
                <Link to="/account">
                  👤 {profile?.full_name?.split(' ')[0] || 'Account'}
                  {profile?.is_admin && <span className="badge-admin">ADMIN</span>}
                </Link>
                <button onClick={() => { signOut(); navigate('/') }}>Logout</button>
              </>
            ) : (
              <Link to="/login">👤 Login</Link>
            )}
            <Link to="/cart">
              🛒 Cart
              {itemCount > 0 && <span className="cart-badge">{itemCount}</span>}
            </Link>
          </div>
        </div>
        <nav className="category-nav">
          <div className="category-nav-inner">
            <Link to="/">All Products</Link>
            {categories.map(c => (
              <Link key={c.id} to={`/category/${c.slug}`}>{c.icon} {c.name}</Link>
            ))}
          </div>
        </nav>
      </header>
    </>
  )
}
