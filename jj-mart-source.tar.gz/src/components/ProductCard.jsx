import { Link } from 'react-router-dom'
import { useCart } from '../context/CartContext'
import { useAuth } from '../context/AuthContext'

export default function ProductCard({ product, onNeedLogin }) {
  const { items, addToCart, updateQuantity } = useCart()
  const { user } = useAuth()

  const cartLine = items.find(i => i.product.id === product.id)
  const offPct = product.mrp > product.price
    ? Math.round(((product.mrp - product.price) / product.mrp) * 100)
    : 0

  function handleAdd() {
    if (!user) { onNeedLogin?.(); return }
    addToCart(product.id, 1)
  }

  return (
    <div className="product-card">
      {product.stock <= 5 && product.stock > 0 && <span className="stock-badge">Only {product.stock} left</span>}
      {product.stock === 0 && <span className="stock-badge" style={{ background: '#8A8276' }}>Out of stock</span>}
      <Link to={`/product/${product.slug}`}>
        <img src={product.image_url} alt={product.name} loading="lazy" />
      </Link>
      <div className="product-body">
        <span className="product-brand">{product.brand}</span>
        <Link to={`/product/${product.slug}`}>
          <div className="product-name">{product.name}</div>
        </Link>
        <span className="product-unit">{product.unit}</span>
        {product.rating > 0 && (
          <span className="product-rating">★ {product.rating} <span style={{ opacity: 0.7 }}>({product.rating_count})</span></span>
        )}
        <div className="price-tag">
          <span className="price-now">₹{product.price}</span>
          {offPct > 0 && <span className="price-mrp">₹{product.mrp}</span>}
          {offPct > 0 && <span className="price-off">{offPct}% OFF</span>}
        </div>

        {product.stock === 0 ? (
          <button className="add-btn" disabled>Out of stock</button>
        ) : cartLine ? (
          <div className="qty-stepper">
            <button onClick={() => updateQuantity(cartLine.id, cartLine.quantity - 1)} aria-label="Decrease quantity">−</button>
            <span>{cartLine.quantity}</span>
            <button onClick={() => updateQuantity(cartLine.id, cartLine.quantity + 1)} aria-label="Increase quantity">+</button>
          </div>
        ) : (
          <button className="add-btn" onClick={handleAdd}>ADD</button>
        )}
      </div>
    </div>
  )
}
