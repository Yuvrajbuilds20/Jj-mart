import { useState } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

export default function Login() {
  const { signIn, signUp } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()
  const [mode, setMode] = useState('login')
  const [form, setForm] = useState({ email: '', password: '', full_name: '', phone: '' })
  const [error, setError] = useState('')
  const [info, setInfo] = useState('')
  const [busy, setBusy] = useState(false)

  const redirectTo = location.state?.from || '/'

  async function handleSubmit(e) {
    e.preventDefault()
    setError(''); setInfo(''); setBusy(true)

    if (mode === 'signup') {
      if (!form.full_name || !form.email || !form.password) {
        setError('Please fill in name, email, and password.')
        setBusy(false)
        return
      }
      const { error } = await signUp(form.email, form.password, form.full_name, form.phone)
      setBusy(false)
      if (error) { setError(error.message) }
      else {
        setInfo('Account created! You can now log in.')
        setMode('login')
      }
      return
    }

    const { error } = await signIn(form.email, form.password)
    setBusy(false)
    if (error) setError(error.message)
    else navigate(redirectTo)
  }

  return (
    <div className="form-card">
      <h2>{mode === 'login' ? 'Welcome back' : 'Create your account'}</h2>
      <p className="sub">{mode === 'login' ? 'Log in to shop at JJ Mart' : 'Sign up to start shopping groceries'}</p>

      {error && <div className="form-error">{error}</div>}
      {info && <div className="form-success">{info}</div>}

      <form onSubmit={handleSubmit}>
        {mode === 'signup' && (
          <>
            <div className="field">
              <label>Full Name</label>
              <input value={form.full_name} onChange={e => setForm({ ...form, full_name: e.target.value })} placeholder="Your name" />
            </div>
            <div className="field">
              <label>Phone</label>
              <input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} placeholder="10-digit mobile number" />
            </div>
          </>
        )}
        <div className="field">
          <label>Email</label>
          <input type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} placeholder="you@example.com" />
        </div>
        <div className="field">
          <label>Password</label>
          <input type="password" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} placeholder="At least 6 characters" />
        </div>
        <button type="submit" className="btn btn-primary" style={{ width: '100%' }} disabled={busy}>
          {busy ? 'Please wait…' : mode === 'login' ? 'Log In' : 'Sign Up'}
        </button>
      </form>

      <div className="form-switch">
        {mode === 'login' ? (
          <>New to JJ Mart? <button onClick={() => { setMode('signup'); setError(''); setInfo('') }}>Create an account</button></>
        ) : (
          <>Already have an account? <button onClick={() => { setMode('login'); setError(''); setInfo('') }}>Log in</button></>
        )}
      </div>
    </div>
  )
}
