import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import ProductCard from '../components/ProductCard'

export default function Home({ onNeedLogin }) {
  const [categories, setCategories] = useState([])
  const [productsByCat, setProductsByCat] = useState({})
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function load() {
      const { data: cats } = await supabase.from('categories').select('*').order('sort_order')
      setCategories(cats || [])

      const grouped = {}
      for (const cat of cats || []) {
        const { data: prods } = await supabase
          .from('products')
          .select('*')
          .eq('category_id', cat.id)
          .eq('is_active', true)
          .order('rating_count', { ascending: false })
          .limit(4)
        grouped[cat.id] = prods || []
      }
      setProductsByCat(grouped)
      setLoading(false)
    }
    load()
  }, [])

  return (
    <>
      <section className="hero">
        <div className="container">
          <h1>Groceries & daily essentials,<br />delivered to your door.</h1>
          <p>JJ Mart brings fresh vegetables, dairy, staples, and household items from local stores to your home — at honest prices.</p>
          <Link to="/category/fruits-vegetables" className="btn btn-primary">Shop Fresh Produce →</Link>
          <div className="hero-stats">
            <div className="hero-stat"><strong>35+</strong><span>Products in stock</span></div>
            <div className="hero-stat"><strong>8</strong><span>Categories</span></div>
            <div className="hero-stat"><strong>₹299</strong><span>Free delivery above</span></div>
          </div>
        </div>
      </section>

      <section className="section container">
        <div className="section-head">
          <h2>Shop by Category</h2>
        </div>
        <div className="cat-grid">
          {categories.map(c => (
            <Link key={c.id} to={`/category/${c.slug}`} className="cat-card">
              <span className="icon">{c.icon}</span>
              <span className="name">{c.name}</span>
            </Link>
          ))}
        </div>
      </section>

      {loading ? (
        <div className="spinner-wrap">Loading products…</div>
      ) : (
        categories.map(cat => (
          productsByCat[cat.id]?.length > 0 && (
            <section className="section container" key={cat.id}>
              <div className="section-head">
                <h2>{cat.icon} {cat.name}</h2>
                <Link to={`/category/${cat.slug}`}>View all →</Link>
              </div>
              <div className="product-grid">
                {productsByCat[cat.id].map(p => (
                  <ProductCard key={p.id} product={p} onNeedLogin={onNeedLogin} />
                ))}
              </div>
            </section>
          )
        ))
      )}
    </>
  )
}
