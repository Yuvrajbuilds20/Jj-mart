import { Link, useNavigate } from 'react-router-dom'
import { useCart } from '../context/CartContext'
import { useAuth } from '../context/AuthContext'

export default function Cart() {
  const { items, updateQuantity, removeItem, subtotal, loading } = useCart()
  const { user } = useAuth()
  const navigate = useNavigate()

  const deliveryFee = subtotal >= 299 || subtotal === 0 ? 0 : 25
  const total = subtotal + deliveryFee

  if (!user) {
    return (
      <div className="empty-state">
        <span className="emoji">🔒</span>
        <h3>Please log in to view your cart</h3>
        <Link to="/login" className="btn btn-secondary" style={{ marginTop: 12 }}>Login</Link>
      </div>
    )
  }

  if (loading) return <div className="spinner-wrap">Loading your cart…</div>

  if (items.length === 0) {
    return (
      <div className="empty-state">
        <span className="emoji">🛒</span>
        <h3>Your cart is empty</h3>
        <p>Add some groceries to get started.</p>
        <Link to="/" className="btn btn-secondary" style={{ marginTop: 12 }}>Start Shopping</Link>
      </div>
    )
  }

  return (
    <div className="container">
      <div className="page-head">
        <h1>Your Cart <span style={{ fontSize: 15, color: 'var(--gray)', fontWeight: 600 }}>({items.length} items)</span></h1>
      </div>

      <div className="cart-layout" style={{ paddingBottom: 50 }}>
        <div>
          {items.map(line => (
            <div className="cart-line" key={line.id}>
              <Link to={`/product/${line.product.slug}`}>
                <img src={line.product.image_url} alt={line.product.name} />
              </Link>
              <div className="cart-line-info">
                <Link to={`/product/${line.product.slug}`}><div className="name">{line.product.name}</div></Link>
                <div className="unit">{line.product.unit}</div>
                <button className="remove-link" onClick={() => removeItem(line.id)}>Remove</button>
              </div>
              <div className="cart-line-qty">
                <div className="qty-stepper">
                  <button onClick={() => updateQuantity(line.id, line.quantity - 1)}>−</button>
                  <span>{line.quantity}</span>
                  <button onClick={() => updateQuantity(line.id, line.quantity + 1)} disabled={line.quantity >= line.product.stock}>+</button>
                </div>
              </div>
              <div className="cart-line-price">₹{(line.quantity * line.product.price).toFixed(0)}</div>
            </div>
          ))}
        </div>

        <div className="summary-card">
          <h3>Order Summary</h3>
          <div className="summary-row"><span>Subtotal</span><span>₹{subtotal.toFixed(0)}</span></div>
          <div className="summary-row">
            <span>Delivery Fee</span>
            <span className={deliveryFee === 0 ? 'free' : ''}>{deliveryFee === 0 ? 'FREE' : `₹${deliveryFee}`}</span>
          </div>
          {deliveryFee > 0 && (
            <p style={{ fontSize: 12, color: 'var(--gray)', marginTop: -4, marginBottom: 10 }}>
              Add ₹{(299 - subtotal).toFixed(0)} more for free delivery
            </p>
          )}
          <div className="summary-row total"><span>Total</span><span>₹{total.toFixed(0)}</span></div>
          <button className="btn btn-primary" style={{ width: '100%', marginTop: 16 }} onClick={() => navigate('/checkout')}>
            Proceed to Checkout →
          </button>
        </div>
      </div>
    </div>
  )
}
